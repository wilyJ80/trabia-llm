# Slides — Trabia LLM (Projeto 2, Equipe 4) — até 15min

## Fonte da verdade
report.pdf (uploads, == docs/report.md) é a versão atual e autoritativa do projeto
(branch refactor/ollama-api): arquitetura hexagonal, OpenAI SDK apontando para Ollama
(phi4-mini padrão), embedders openai-compatible (768d, nomic-embed-text) OU spacy (300d).
docs/slides.md, docs/collage.png e docs/print_medium.png são de uma iteração ANTERIOR
(langchain + Gemini + spaCy + CLI) — não usar como fonte, exceto onde o conteúdo ainda
bate com o report atual (ex.: base documental, protocolo experimental, resultados).

## Sequência de títulos (estilo substantivo, parênteses = conteúdo)
1. Capa — Extrator Estruturado com LLM, RAG e Validação
2. Definição do Problema
3. Base Documental
4. Arquitetura da Solução
5. Modelos e Componentes
6. Pipeline de Ingestão
7. Recuperação Vetorial
8. Extração Estruturada e Validação
9. Interface Web
10. Protocolo Experimental
11. Resultados Experimentais
12. Análise Crítica
13. Conclusão
14. Perguntas

Checagem: lendo só os títulos dá pra acompanhar a história (problema → dados →
arquitetura → como cada peça funciona → interface → como foi testado → o que deu certo
e o que falhou → fechamento). Sem títulos-punchline.

## Sistema visual (Nocturne)
- fundo padrão --color-bg; divisores/capa usam --color-section (indigo saturado) — só 2 fundos
- título 64px, subtítulo/kicker 24-28px, corpo 32-34px — tudo inline, repetido por slide
- diagramas de arquitetura/pipeline: caixas com --color-surface + --shadow-md, não SVG decorativo
- screenshot real da interface (recriada a partir de src/api/static, com dados de exemplo)
- tabela de resultados usa o padrão .table tokens (cores/spacing), inline
